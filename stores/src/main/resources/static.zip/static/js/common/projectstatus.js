function getProjectRole(){
    var role = ["产品经理","设计师","硬件工程师","软件工程师","运营","公关",
         "市场销售","人力资源","财务","法务","其他"];
	return role;
}

function getProjectPhase(){
    var phase = ["想法阶段","Demo 阶段","产品已上线","有运营数据","已停止运营"];
    return phase;
}

function getFinancePhase(){
    var phase = ["种子","天使","Pre-A","A 轮","B 轮","C 轮","D 轮","E 轮","F 轮","Pre-IPO"];
    return phase;
}


